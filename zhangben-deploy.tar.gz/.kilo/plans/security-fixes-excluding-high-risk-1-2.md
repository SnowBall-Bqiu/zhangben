# Security Fixes Excluding High Risk 1 and 2

## Output Language Rule

- All user-facing output introduced or modified by this work must use Chinese.
- This includes API error messages, success messages, validation messages, frontend UI labels, toast messages, and final implementation summaries.
- Existing Chinese wording style should be preserved where possible.

## Scope

Implement all previously reported security fixes except the two explicitly excluded items:

- Excluded: default account `admin/123456` initial takeover flow. Do not change database initialization or default account creation behavior.
- Excluded: multi-user object-level authorization / owner isolation. Do not add `user_id` columns or per-user filtering to accounts, categories, transactions, reports, or exports.

Everything else from the audit should be addressed with minimal, localized changes.

## Goals

- Add CSRF protection for state-changing API requests.
- Require current password when changing password.
- Close `must_change_password` profile bypass.
- Harden session/auth middleware behavior.
- Reject invalid request bodies and malformed JSON with 400-level responses instead of 500.
- Add server-side validation for query, path, and body inputs.
- Fix pagination bypass, LIKE wildcard expansion, CSV formula injection edge cases, and route ordering bugs.
- Add basic HTTP security headers and disable Express fingerprinting.
- Preserve existing single-user data model and default-account initialization.

## Implementation Plan

### 1. Add Shared Security And Validation Helpers

Create small server-side helpers, keeping them simple and CommonJS-compatible:

- `server/middleware/csrf.js`
  - Generate a random session-bound CSRF token using Node `crypto`.
  - Expose a safe helper/middleware to issue token through `GET /api/auth/csrf`.
  - Validate `X-CSRF-Token` on all `POST`, `PUT`, `PATCH`, and `DELETE` requests under `/api`, except `GET/HEAD/OPTIONS`.
  - Return `403` with a clear Chinese JSON message when token is missing or invalid.

- `server/middleware/security-headers.js` or inline middleware in `server/index.js`
  - `app.disable('x-powered-by')`.
  - Add `X-Content-Type-Options: nosniff`.
  - Add `X-Frame-Options: DENY`.
  - Add `Referrer-Policy: no-referrer` or `strict-origin-when-cross-origin`.
  - Add a conservative CSP that still allows the built Vite app to load its own assets. Prefer `default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; base-uri 'self'; frame-ancestors 'none'`.

- `server/utils/validation.js`
  - `isPositiveInteger(value)` / `parsePositiveInteger(value, field)`.
  - `parsePageLimit(page, limit)` with `page >= 1` and `1 <= limit <= 100`.
  - `validateType(value, allowed, field)` for `income`, `expense`, and account/category types as appropriate.
  - `validateName(value, field, max)` trims and rejects empty, overlong, and control-character-heavy values.
  - `parseAmount(value, field)` using `Number(value)`, `Number.isFinite`, `> 0`, max amount, and max 2 decimal places.
  - `validateDate(value)` requiring real `YYYY-MM-DD` dates.
  - `escapeLike(value)` escaping `%`, `_`, and `\`, to be used with `LIKE ? ESCAPE '\'`.

Keep helper messages consistent with the app's existing Chinese JSON responses.

### 2. Update `server/index.js`

- Disable `X-Powered-By` before routes.
- Add security headers middleware before static/API routes.
- Keep `express.json()` and `express.urlencoded()` if needed for compatibility, but add:
  - A content-type guard for mutating `/api` requests so API writes accept only JSON, except if keeping form login compatibility is required. Preferred: require JSON for all API writes.
  - A JSON parse error handler that returns `400` for malformed JSON.
- Add CSRF validation middleware after session setup and before routes.
- Keep existing route mounting and single-user model intact.

Important ordering:

1. security headers
2. body parsers
3. session
4. csrf validation
5. routes
6. static SPA fallback
7. error handler

### 3. Update Client API For CSRF

Modify `client/src/api/index.js`:

- Add a cached `fetchCsrfToken()` that calls `GET /api/auth/csrf`.
- For mutating methods (`POST`, `PUT`, `PATCH`, `DELETE`), ensure a CSRF token exists and send it as `X-CSRF-Token`.
- Preserve current function exports.
- Make response parsing robust when a response is not JSON.
- On login/logout, handle token reuse or refresh cleanly. A simple approach is to fetch token before every mutating call or cache it and refetch once on CSRF failure.

### 4. Harden Auth And Password Change

Update `server/routes/auth.js`:

- Add `GET /api/auth/csrf` route.
- On successful login, regenerate the session ID before storing `userId` and `username` to reduce session fixation risk, while preserving/refreshing CSRF token after regeneration.
- Change `/change-password` to require `currentPassword` and `newPassword`.
- Fetch the current user by `req.session.userId`; return `401` if missing.
- Verify `currentPassword` with bcrypt before updating.
- Keep `must_change_password = 0` after successful password change.
- Add sensible password validation, at minimum length >= 6 as currently used.
- Update `/profile` to reject requests when `must_change_password = 1`, closing the profile bypass.
- Trim and length-limit `username` and `nickname` server-side.

Update frontend callers:

- `client/src/pages/ChangePassword.jsx`: add a current-password field even in forced password change flow.
- Settings page password-change form: pass `currentPassword` and `newPassword` to `changePassword`.
- `client/src/api/index.js`: change `changePassword(currentPassword, newPassword)` or accept an object while updating all callers.

### 5. Harden `authMiddleware`

Update `server/middleware/auth.js`:

- If `req.session.userId` exists but no user is found, destroy the session and return `401`.
- Replace `req.path.includes('change-password')` with exact allowlisting where needed.
- Since `/api/auth` routes are not mounted through this middleware, keep middleware focused on protected business routes. Auth routes should perform their own explicit checks.

### 6. Fix Transaction Validation, Pagination, Search, And CSV

Update `server/routes/transactions.js`:

- Replace `csvSafe()` with stricter formula detection:
  - Escape double quotes.
  - Detect formula characters after leading whitespace/control characters/BOM.
  - Prefix a single quote when normalized value starts with `=`, `+`, `-`, or `@`.
  - Include `\r`, `\n`, `\t`, and spaces in the detection.
- Validate GET query:
  - `type` must be absent, `all`, `income`, or `expense`.
  - `page` and `limit` must be valid bounded integers.
  - `search` should be trimmed, length-limited, and LIKE-escaped with `ESCAPE '\'`.
- Use validated `pageNum`, `limitNum`, and `offset` in SQL and response JSON.
- Validate transaction body for create/update:
  - `name`: trimmed, non-empty, max 50.
  - `type`: `income` or `expense`.
  - `amount`: finite positive number, bounded, max 2 decimals.
  - `profit`: optional finite positive number, bounded, max 2 decimals.
  - `transaction_date`: real `YYYY-MM-DD`.
  - `category_id` / `account_id`: optional positive integers; confirm existence when provided.
  - Category type should match transaction type when `category_id` is provided.
  - `note`: optional string, max 500, reject/control trim as appropriate.
- Validate `:id` as a positive integer for update/delete.
- Return `400` for validation errors and `404` for missing referenced records.

Do not add user ownership filtering, per the user's exclusion.

### 7. Fix Category And Account Routes

Update `server/routes/categories.js`:

- Move `PUT /reorder` before `PUT /:id`.
- Validate `type` as `income` or `expense` for category create/query.
- Validate `name` length and trim, likely max 10 or 30 to match UI expectations.
- Validate `icon` length if present.
- Validate `:id` positive integer.
- Validate `sort_order` positive integer when provided.
- For update/delete, check `result.changes`; return `404` when no row was affected.
- Validate reorder `ids` as non-empty positive integer array and check all rows updated.

Update `server/routes/accounts.js`:

- Move `PUT /reorder` before `PUT /:id`.
- Validate account `name`, `type`, `icon`, `sort_order`, and `:id`.
- Use `result.changes` checks for update/delete.
- Validate reorder `ids` as positive integer array and check all rows updated.

Do not add per-user ownership checks.

### 8. Validate Dashboard Query Inputs

Update `server/routes/dashboard.js`:

- Validate `/monthly` query:
  - `year` integer in a reasonable range, such as 1970-2100.
  - `month` integer 1-12.
- Use validated values to construct `monthStart` and `monthEnd`.
- Keep existing global single-user aggregation behavior unchanged.

### 9. Static Fallback And Standard Files

Minimal options:

- Return `404` for unknown `/api` paths if not already handled.
- Consider explicit `404` for `robots.txt`, `manifest.json`, and `/.well-known/security.txt` if files do not exist, instead of returning the SPA shell. If changing this is considered too broad, leave as low-risk config debt.

Since user requested all non-excluded findings, prefer adding explicit small handlers before SPA fallback:

- `/robots.txt` returns a small text response or 404.
- `/manifest.json` returns 404 JSON/text unless a real manifest is added.
- `/.well-known/security.txt` returns 404.

### 10. Verification Plan

Run after implementation:

- `npm run build`
- Start server if needed with `npm run start` or reuse existing server.
- Non-destructive runtime checks:
  - Login SQL injection payloads still return `401`.
  - Malformed JSON returns `400`, not `500`.
  - Missing CSRF on POST returns `403`.
  - Client login succeeds with CSRF flow.
  - `GET /api/transactions?page=abc&limit=xyz` returns `400`.
  - `GET /api/transactions?page=1&limit=-1` returns `400`.
  - `GET /api/transactions?search=%25` no longer treats `%` as wildcard unless literal record names contain `%`.
  - `GET /api/dashboard/monthly?year=abc&month=999` returns `400`.
  - `/%2e%2e/package.json` does not reveal files.
  - Security headers are present and `X-Powered-By` is absent.

Manual/browser checks:

- Normal login works.
- Forced password change now requires current password and succeeds with correct current password.
- Settings password change works with current password.
- Creating/editing transactions still works with valid data.
- Category/account reorder works after route order fix.
- CSV export still downloads and formula-like fields are escaped.

## Non-Goals

- Do not remove or alter the default admin creation flow.
- Do not add multi-user ownership columns or filters.
- Do not redesign the UI beyond fields needed for current-password input.
- Do not introduce large dependencies unless necessary; prefer small local helpers.
